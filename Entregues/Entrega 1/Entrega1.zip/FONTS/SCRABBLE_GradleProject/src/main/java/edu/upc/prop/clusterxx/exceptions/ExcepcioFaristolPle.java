package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioFaristolPle extends RuntimeException {
    public ExcepcioFaristolPle(String message) {
        super(message);
    }
}
