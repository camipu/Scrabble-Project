package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioEstadistiquesBuides extends RuntimeException {
    public ExcepcioEstadistiquesBuides(String message) {
        super(message);
    }
}
