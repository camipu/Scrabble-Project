package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioSacNoConteLaFitxa extends RuntimeException {
    public ExcepcioSacNoConteLaFitxa(String message) {
        super(message);
    }
}
