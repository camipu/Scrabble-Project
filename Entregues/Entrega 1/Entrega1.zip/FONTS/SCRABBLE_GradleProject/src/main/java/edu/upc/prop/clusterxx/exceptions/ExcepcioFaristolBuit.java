package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioFaristolBuit extends RuntimeException {
    public ExcepcioFaristolBuit(String message) {
        super(message);
    }
}
