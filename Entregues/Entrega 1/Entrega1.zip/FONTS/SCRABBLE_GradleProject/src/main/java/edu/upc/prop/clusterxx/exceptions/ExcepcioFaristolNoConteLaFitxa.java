package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioFaristolNoConteLaFitxa extends RuntimeException {
    public ExcepcioFaristolNoConteLaFitxa(String message) {
        super(message);
    }
}
