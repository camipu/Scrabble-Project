package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioCasellaOcupada extends RuntimeException {
    public ExcepcioCasellaOcupada(String missatge) {
        super(missatge);
    }
}
