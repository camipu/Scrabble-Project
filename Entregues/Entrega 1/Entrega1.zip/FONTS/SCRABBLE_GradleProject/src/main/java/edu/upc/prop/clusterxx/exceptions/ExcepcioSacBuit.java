package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioSacBuit extends RuntimeException {
    public ExcepcioSacBuit(String message) {
        super(message);
    }
}
