package edu.upc.prop.clusterxx.exceptions;

public class ExcepcioCasellaBuida extends RuntimeException {
    public ExcepcioCasellaBuida(String message) {
        super(message);
    }
}
